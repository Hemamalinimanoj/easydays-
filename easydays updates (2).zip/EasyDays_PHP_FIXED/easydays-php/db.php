<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/questions.php';

// Never print PHP warnings on the page (they break JSON / headers). Errors go to the PHP log.
ini_set('display_errors', '0');
error_reporting(E_ALL & ~E_DEPRECATED & ~E_STRICT);

// Make mysqli throw exceptions (so we can show a clear message)
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

// Human friendly hint for the admin page
function db_hint(Throwable $e): string {
    $code = (int)$e->getCode();
    if (!extension_loaded('mysqli')) {
        return 'PHP extension "mysqli" is not enabled. In php.ini remove the ; before extension=mysqli, then restart Apache.';
    }
    if ($code === 2002) {
        return 'MySQL is not running (or uses another port). Open XAMPP Control Panel and click Start next to MySQL. If it stops again, click the MySQL "Logs" button.';
    }
    if ($code === 1045) {
        return 'MySQL username or password is wrong. Set DB_USER and DB_PASS in config.php (XAMPP default: root with empty password).';
    }
    return 'Technical details: ' . $e->getMessage();
}

// Run a SELECT and return all rows as arrays
function rows(mysqli $db, string $sql): array {
    $out = [];
    $res = $db->query($sql);
    while ($r = $res->fetch_assoc()) {
        $out[] = $r;
    }
    $res->free();
    return $out;
}

// Run a SELECT and return the first column of the first row
function scalar(mysqli $db, string $sql) {
    $res = $db->query($sql);
    $r = $res->fetch_row();
    $res->free();
    return $r ? $r[0] : null;
}

function db(): mysqli {
    static $db = null;
    if ($db instanceof mysqli) {
        return $db;
    }
    if (!extension_loaded('mysqli')) {
        throw new RuntimeException('mysqli extension missing');
    }

    // Try the configured port first, then the usual XAMPP ports (3306 / 3307)
    $ports = array_values(array_unique([(int)DB_PORT, 3306, 3307]));
    $last  = null;
    foreach ($ports as $port) {
        try {
            $db = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME, $port);
            break;
        } catch (mysqli_sql_exception $e) {
            $last = $e;
            $code = (int)$e->getCode();
            if ($code === 1049) {
                // database does not exist yet -> create it (works on XAMPP / root)
                $tmp = new mysqli(DB_HOST, DB_USER, DB_PASS, '', $port);
                $tmp->query('CREATE DATABASE IF NOT EXISTS `' . DB_NAME . '` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci');
                $tmp->close();
                $db = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME, $port);
                break;
            }
            if ($code !== 2002) {
                throw $e;      // wrong password etc. -> no point trying other ports
            }
        }
    }
    if (!($db instanceof mysqli)) {
        throw $last ?: new RuntimeException('Database connection failed');
    }
    $db->set_charset('utf8mb4');

    // Create the table automatically (one column per question)
    $cols = '';
    foreach (questions() as $id => $_) {
        $cols .= '`' . $id . '` TEXT NULL, ';
    }
    $db->query(
        'CREATE TABLE IF NOT EXISTS `responses` ('
        . '`id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, '
        . '`created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, '
        . $cols
        . 'INDEX (`created_at`)'
        . ') ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci'
    );
    return $db;
}
