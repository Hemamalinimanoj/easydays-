<?php
// ===== Easy Days settings =====
// Database (XAMPP default: user "root", empty password)
define('DB_HOST', '127.0.0.1');
define('DB_PORT', 3306);          // change to 3307 if your XAMPP MySQL uses that port
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'easydays');    // created automatically if it does not exist

// Client login for admin.php  -> CHANGE THE PASSWORD before sharing!
define('ADMIN_USER', 'admin');
define('ADMIN_PASS', 'EasyDays@2026');
